Class Mesa{

    Mesa mesa = new Mesa();

    mesa(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    sostener();

}
mesa.sostener();