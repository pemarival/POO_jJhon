Class Puerta{

    Puerta puerta = new Puerta();

    puerta(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    abrir();
    cerrar();

}
Puerta.abrir();
Puerta.cerrar();