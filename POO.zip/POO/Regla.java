Class Regla{

    Regla regla = new Regla();

    constuctor(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    medir();

}
regla.medir();
