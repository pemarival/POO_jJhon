Class Ventana{

    Ventana ventana = new Ventana();

    ventana(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    abrir();
    cerrar();

}
ventana.abrir();
ventana.cerrar();