Class Candado{

    Candado candado = new Candado();

    constuctor(material, marca,color) {
        this.material = material;
        this.forma = marca;
        this.color = color;
    }

    asegurar();

}
candado.asegurar();