Class Computador{

    Computador computador = new Computador();

    computador(marca, tamaño, tipo) {
        this.marca = marca;
        this.tamaño = tamaño;
        this.tipo = tipo;
    }

    investigar();

}
computador.investigar();
