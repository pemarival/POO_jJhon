Class Techo{

    Techo techo = new Techo();

    techo(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    cubrir();

}
Ventana.abrir();
Ventana.cerrar();