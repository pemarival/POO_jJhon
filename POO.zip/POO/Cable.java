Class cable{

    Cable cable = new Cable();

    cable(color, largo, marca) {
        this.color = color;
        this.largo = largo;
        this.marca = marca;
    }

    cargar();

}
cable.cargar();