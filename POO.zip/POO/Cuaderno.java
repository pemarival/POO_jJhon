Class Cuaderno{

    Cuaderno cuaderno = new Cuaderno();

    cuaderno(diseño, material, precio) {
        this.diseño = diseño;
        this.material = material;
        this.precio = precio;
    }

    mostrar();

}
cuaderno.mostrar();