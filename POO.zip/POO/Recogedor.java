Class Recogedor{

    Recogedor recogedor = new Recogedor();

    recogedor(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    recoger();

}
recogedor.recoger();