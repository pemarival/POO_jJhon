Class Mouse{

    Mouse mouse = new Mouse();

    mouse(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    usar();

}
mouse.usar();