Class Silla{

    Silla silla = new Silla();

    silla(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    sostener();

}
Silla.sostener();
