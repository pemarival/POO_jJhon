Class Impresora{

    Impresora impresora = new Impresora();

    impresora(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    imprimir();

}
impresora.imprimir();