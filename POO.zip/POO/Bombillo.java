Class Bombillo{

    Bombillo bombillo = new Bombillo();

    bombillo(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    alumbrar();

}
bombillo.alumbrar();