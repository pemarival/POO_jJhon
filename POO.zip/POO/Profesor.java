Class Profesor{

    Profesor profesor = new Profesor();

    profesor(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    enseñar();

}
profesor.enseñar();