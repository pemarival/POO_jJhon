Class Piso{

    Piso piso = new Piso();

    piso(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    sostener();

}
piso.sostener();
