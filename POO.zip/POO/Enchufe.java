Class Enchufe{

    Enchufe enchufe = new Enchufe();

    constuctor(marca, color, costo) {
        this.marca = marca;
        this.color = color;
        this.costo = costo;
    }

    conectar();

}
enchufe.conectar();