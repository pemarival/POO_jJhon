Class Escoba{

    Escoba escoba = new Escoba();

    escoba(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    barrer();

}
escoba.barrer();