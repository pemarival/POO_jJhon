Class Llave{

    Llave llave = new Llave();

    llave(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    acceder();

}
llave.acceder();