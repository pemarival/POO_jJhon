Class Auricular{

    Auricular auricular = new Auricular();

    auricular(marca,color,precio) {
        this.marca = marca;
        this.color = color;
        this.precio = precio;
    }

    escuchar();
}

auricular.escuchar();
