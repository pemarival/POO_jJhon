Class Celular{

    Celular celular = new Celular();

    celular(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    usar();

}
celular.usar();