Class Aire{

    Aire aire = new Aire();

    aire(tamaño, marca, color) {
        this.tamaño = tamaño;
        this.marca = marca;
        this.color = color;
    }

    ventilar();

}
aire.ventilar();