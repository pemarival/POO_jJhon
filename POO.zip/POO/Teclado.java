Class Teclado{

    Teclado teclado = new Teclado();

    teclado(codigo, color, marca) {
        this.codigo = codigo;
        this.color = color;
        this.marca = marca;
    }

    escribir();

}
teclado.escribir();