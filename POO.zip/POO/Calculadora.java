Class Calculadora{

    Calculadora calculadora = new Calculadora();

    calculadora(costo, color, precio) {
        this.costo = costo;
        this.color = color;
        this.precio = precio;
    }

    calcular();

}
calculadora.calcular();