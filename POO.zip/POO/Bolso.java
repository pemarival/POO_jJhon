Class Bolso{

    Bolso bolso = new Bolso();

    bolso(marca, precio, color) {
        this.marca = marca;
        this.precio = precio;
        this.color = color;
    }

    guardar();

}
bolso.guardar();
