Class Aprendiz{

    Aprendiz aprendiz = new Aprendiz();

    aprendiz(nombre, numero, ficha) {
        this.nombre = nombre;
        this.numero = numero;
        this.ficha = ficha;
    }

    aprender();

}
aprendiz.aprender();