Class Cartuchera{

    Cartuchera cartuchera = new Cartuchera();

    constuctor(tamaño, forma, color) {
        this.tamaño = tamaño;
        this.forma = forma;
        this.color = color;
    }

    guardar();

}
cartuchera.guardar();
