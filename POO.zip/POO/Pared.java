Class Pared{

    Pared pared = new Pared();

    pared(material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    proteger();

}
pared.proteger();