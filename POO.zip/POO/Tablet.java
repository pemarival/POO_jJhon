Class Tablet{

    Tablet tablet = new Tablet();

    tablet (material,forma,color) {
        this.material = material;
        this.forma = forma;
        this.color = color;
    }

    investigar();

}
tablet.investigar();