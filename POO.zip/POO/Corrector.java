Class Corrector{

    Corrector corrector = new Corrector();

    corrector(marca, material, tamaño) {
        this.marca = marca;
        this.material = material;
        this.tamaño = tamaño;
    }

    borrar();

}
corrector.borrar();